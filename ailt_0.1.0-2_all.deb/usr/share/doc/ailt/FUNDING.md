# Support AILT – AI Linux Terminal

If you enjoy using AILT and other tools, please consider supporting the project:

- **Buy me a coffee:** 

    BTC - bc1qsl5qp3m83zxl3ehacxg23qpwqtgq2f2qqsxm23

Your support helps keep development going and improves features for everyone!
